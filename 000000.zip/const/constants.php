<?php
echo "<pre>";
print_r(get_defined_constants(true));
echo "</pre>";