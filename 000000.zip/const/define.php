<?php
// 함수를 이용해서 선언
define("PI", 3.14);
echo PI;