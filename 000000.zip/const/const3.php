<?php
const DAELIM = "daelim univ1234";
echo DAELIM;
echo DAELIM;
echo DAELIM;
echo DAELIM;
echo DAELIM;