<?php
// 예약어, 함수
const PI = 3.14;
echo PI;