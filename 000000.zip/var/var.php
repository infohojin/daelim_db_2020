<?php

$daelim = "대림대학교";
echo $daelim."\n";

// daelim 변수야~~~
echo ${"daelim"};

$name = "daelim";
echo ${$name};