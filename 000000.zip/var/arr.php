<?php
$arr = array(1,2,3,4,5,6,7);
var_dump($arr);
echo $arr[3]."\n";

echo "배열안에 몇개가 있나요".count($arr);