<?php

$hello = "대림대학교";
var_dump($hello);
