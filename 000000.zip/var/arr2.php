<?php

$arr = ['apple'=>"사과",'kiwi'=>"키위",'banana'=>"바나나"];
echo $arr['apple'];
echo $arr['kiwi'];
echo $arr['banana'];