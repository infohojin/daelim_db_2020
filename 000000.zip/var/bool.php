<?php

$bool = true;
var_dump($bool);
echo $bool;
