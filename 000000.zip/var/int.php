<?php
$num = 123;
var_dump($num);

$n = "456";
var_dump($n);