<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    
    <?php
        echo "대림대학교";
    ?>

    <hr>

    <?php
        print "123456 학번 대남이 입니다.";
    ?>



</body>
</html>