<?php

require "hello.php";
require "hello.php";

print hello();


