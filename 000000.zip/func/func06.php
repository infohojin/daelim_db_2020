<?php
// C언어 ... 함수형
// 파이썬 func
function daelim()
{
    echo "대림대학교";
    print "<hr>";
}

for ($i=0; $i<5; $i++) {
    daelim();
}



/*
echo "대림대학교";
print "<hr>";

echo "대림대학교";
print "<hr>";

echo "대림대학교";
print "<hr>";

echo "대림대학교";
print "<hr>";
*/
